import React from "react";

const OfferSection: React.FC = () => {
  return (
    <></>
  );
};

export default OfferSection;
